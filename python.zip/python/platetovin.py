import requests
import json

url = 'https://platetovin.com/api/convert'
payload = {
    "state": "FL",
    "plate": "HXKR85"
}
headers = {
    'Authorization': 'iBVnCES3bvlUzGX',
    'Content-Type': 'application/json',
    'Accept': 'application/json'
}

response = requests.post(url, json=payload, headers=headers)

if response.status_code == 200:
    data = response.json()
    json_output = json.dumps(data, indent=4)  # Convert data to JSON format
    print("Output (JSON):")
    print(json_output)
else:
    print("Error:", response.status_code)